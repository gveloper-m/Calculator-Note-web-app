var list = ["row1", "row2", "row3", "row4", "row5", "row6", "row7", "row8", "row9"];

window.onload = function() {
    // Check if there is a saved note in local storage
    if (localStorage.getItem('savedNote') !== null) {
        // Retrieve the saved note and set it in the textarea
        document.getElementById('note').value = localStorage.getItem('savedNote');
    }
};

function a() {
    let first = parseFloat(document.getElementById("first").value);
    let second = parseFloat(document.getElementById("second").value);
    var result = first + second;


    document.getElementById("first").value = result;
    document.getElementById("second").value = 0;

    document.getElementById("out").innerText = result;

    for (let i = 0; i < 9; i++) {
        let temp = list[i];


        if (document.getElementById(temp).innerText === "Row") {
            document.getElementById(temp).innerText = result;
            console.log(document.getElementById(temp).innerText);

            return 0;
      
           

        }

    }

    console.log(result);
}


function b() {
    let first = parseFloat(document.getElementById("first").value);
    let second = parseFloat(document.getElementById("second").value);
    let result = first - second;

    document.getElementById("first").value = result;
    document.getElementById("second").value = 0;

    document.getElementById("out").innerText = result;

    for (let i = 0; i < 9; i++) {
        let temp = list[i];


        if (document.getElementById(temp).innerText === "Row") {
            document.getElementById(temp).innerText = result;
            console.log(document.getElementById(temp).innerText);
            return 0;
        }
    }

}
function c() {
    let first = parseFloat(document.getElementById("first").value);
    let second = parseFloat(document.getElementById("second").value);
    let result = first / second;

    document.getElementById("first").value = result;
    document.getElementById("second").value = 0;

    document.getElementById("out").innerText = result;

    for (let i = 0; i < 9; i++) {
        let temp = list[i];
        if (document.getElementById(temp).innerText === "Row") {
            document.getElementById(temp).innerText = result;
            console.log(document.getElementById(temp).innerText);
            return 0;
        }
    }
    console.log(result);
}
function d() {
    let first = parseFloat(document.getElementById("first").value);
    let second = parseFloat(document.getElementById("second").value);
    let result = first * second;

    document.getElementById("first").value = result;
    document.getElementById("second").value = 0;

    document.getElementById("out").innerText = result;

    for (let i = 0; i < 9; i++) {
        let temp = list[i];


        if (document.getElementById(temp).innerText === "Row") {
            document.getElementById(temp).innerText = result;
            console.log(document.getElementById(temp).innerText);
            return 0;
        }
    }
    console.log(result);
}

function clean() {
    let first = parseFloat(document.getElementById("first").value);
    let second = parseFloat(document.getElementById("second").value);
    let result = first * second;

    document.getElementById("first").value = 0;
    document.getElementById("second").value = 0;
    document.getElementById("out").innerText = 0;
    console.log(0);
}

function del(button) {

    let temp = button.id;
    let pos = temp.charAt(1);
    let toDel = list[pos - 1];
    document.getElementById(toDel).innerText = "Row";
    console.log(toDel);

}

function save() {
    // Get the value of the note textarea
    var noteValue = document.getElementById('note').value;
    
    // Save the note in local storage
    localStorage.setItem('savedNote', noteValue);
    
    alert('Note saved successfully!');
}
